package kz.qarajat;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.Calendar;

public class ReminderReceiver extends BroadcastReceiver {

    static void configure(Context c, boolean on, int h, int m) {
        c.getSharedPreferences("rem", 0).edit()
                .putBoolean("on", on).putInt("h", h).putInt("m", m).apply();
        schedule(c);
    }

    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent in = new Intent(c, ReminderReceiver.class);
        in.setAction("kz.qarajat.REMIND");
        PendingIntent pi = PendingIntent.getBroadcast(c, 1, in,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        am.cancel(pi);
        SharedPreferences p = c.getSharedPreferences("rem", 0);
        if (!p.getBoolean("on", false)) return;
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, p.getInt("h", 21));
        cal.set(Calendar.MINUTE, p.getInt("m", 0));
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) {
            schedule(c);
            return;
        }
        if (!c.getSharedPreferences("rem", 0).getBoolean("on", false)) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("rem", "Еске салғыш", NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent open = PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, "rem")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Қаражат")
                .setContentText("Бүгінгі шығыстарды жазуды ұмытпаңыз")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        nm.notify(1, n);
        schedule(c);
    }
}
