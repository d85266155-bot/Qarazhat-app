package kz.qarajat;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

public class QuickActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new QB(), "AndroidQ");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                web.requestFocus();
                web.postDelayed(() -> {
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT);
                }, 300);
            }
        });
        load(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        load(i);
    }

    private void load(Intent i) {
        String t = i.getStringExtra("t");
        web.loadUrl("file:///android_asset/quick.html?r=" + System.currentTimeMillis() + "#" + ("i".equals(t) ? "i" : "e"));
    }

    public class QB {
        @JavascriptInterface
        public String getCfg() {
            return getSharedPreferences("q", 0).getString("cfg", "{}");
        }

        @JavascriptInterface
        public void save(String tx, String cfg, String bal, String sub) {
            try {
                SharedPreferences p = getSharedPreferences("q", 0);
                JSONArray a = new JSONArray(p.getString("pending", "[]"));
                a.put(new JSONObject(tx));
                p.edit().putString("pending", a.toString()).putString("cfg", cfg).apply();
            } catch (Exception e) {
                // ignore
            }
            getSharedPreferences("w", 0).edit().putString("bal", bal).putString("sub", sub).apply();
            QWidget.refresh(QuickActivity.this);
        }

        @JavascriptInterface
        public void close() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public void openApp() {
            runOnUiThread(() -> {
                Intent i = new Intent(QuickActivity.this, MainActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                finish();
            });
        }
    }
}
