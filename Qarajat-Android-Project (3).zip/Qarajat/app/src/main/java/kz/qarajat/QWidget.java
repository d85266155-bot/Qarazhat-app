package kz.qarajat;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class QWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) m.updateAppWidget(id, build(c));
    }

    static RemoteViews build(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        SharedPreferences p = c.getSharedPreferences("w", 0);
        v.setTextViewText(R.id.w_bal, p.getString("bal", "—"));
        v.setTextViewText(R.id.w_sub, p.getString("sub", "Қосымшаны бір рет ашыңыз"));
        v.setOnClickPendingIntent(R.id.w_inc, pi(c, "i", 31));
        v.setOnClickPendingIntent(R.id.w_exp, pi(c, "e", 32));
        v.setOnClickPendingIntent(R.id.w_scan, pi(c, "scan", 33));
        v.setOnClickPendingIntent(R.id.w_root, pi(c, "", 30));
        return v;
    }

    static PendingIntent pi(Context c, String a, int code) {
        Intent i = new Intent(c, MainActivity.class);
        i.setAction("kz.qarajat.OPEN." + code);
        i.putExtra("a", a);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, QWidget.class));
        for (int id : ids) m.updateAppWidget(id, build(c));
    }
}
