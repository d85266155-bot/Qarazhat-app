package kz.qarajat;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class QWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) m.updateAppWidget(id, build(c));
    }

    static RemoteViews build(Context c) {
        SharedPreferences p = c.getSharedPreferences("w", 0);
        boolean ru = "ru".equals(p.getString("lang", "kk"));
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setTextViewText(R.id.w_title, ru ? "Қаражат · общий баланс" : "Қаражат · жалпы қалдық");
        v.setTextViewText(R.id.w_bal, p.getString("bal", "—"));
        v.setTextViewText(R.id.w_sub, p.getString("sub", ru ? "Откройте приложение один раз" : "Қосымшаны бір рет ашыңыз"));
        v.setTextViewText(R.id.w_inc, ru ? "＋ Доход" : "＋ Кіріс");
        v.setTextViewText(R.id.w_exp, ru ? "－ Расход" : "－ Шығыс");
        v.setOnClickPendingIntent(R.id.w_inc, quick(c, "i", 41));
        v.setOnClickPendingIntent(R.id.w_exp, quick(c, "e", 42));
        v.setOnClickPendingIntent(R.id.w_scan, open(c, "scan", 43));
        v.setOnClickPendingIntent(R.id.w_root, open(c, "", 40));
        return v;
    }

    static PendingIntent quick(Context c, String t, int code) {
        Intent i = new Intent(c, QuickActivity.class);
        i.setAction("kz.qarajat.QUICK." + t);
        i.putExtra("t", t);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static PendingIntent open(Context c, String a, int code) {
        Intent i = new Intent(c, MainActivity.class);
        i.setAction("kz.qarajat.OPEN." + code);
        i.putExtra("a", a);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int id : m.getAppWidgetIds(new ComponentName(c, QWidget.class)))
            m.updateAppWidget(id, build(c));
        for (int id : m.getAppWidgetIds(new ComponentName(c, QWidgetMini.class)))
            m.updateAppWidget(id, QWidgetMini.build(c));
    }
}
