package kz.qarajat;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_SCAN = 11;
    private static final int REQ_PICK = 12;
    private static final int REQ_VOICE = 13;
    private static final int REQ_PHOTO = 14;
    private WebView web;
    private Uri pending;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        applyBars(night);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                String a = getIntent().getStringExtra("a");
                if (a != null && !a.isEmpty()) {
                    js("widgetAction('" + a + "')");
                    getIntent().removeExtra("a");
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        String a = i.getStringExtra("a");
        if (a != null && !a.isEmpty()) {
            js("widgetAction('" + a + "')");
            i.removeExtra("a");
        }
    }

    private void applyBars(boolean dark) {
        int bg = dark ? 0xFF0E1011 : 0xFFF7F7F5;
        web.setBackgroundColor(bg);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0
                : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) js("if(window.syncData)syncData()");
    }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private boolean okId(String id) {
        return id != null && id.matches("r[0-9]+");
    }

    private File imgFile(String id) {
        return new File(new File(getFilesDir(), "receipts"), id + ".jpg");
    }

    public class Bridge {
        @JavascriptInterface
        public void scanReceipt() {
            runOnUiThread(() -> startChooser(REQ_SCAN));
        }

        @JavascriptInterface
        public void pickPhoto() {
            runOnUiThread(() -> startChooser(REQ_PHOTO));
        }

        @JavascriptInterface
        public String getImage(String id) {
            try {
                if (!okId(id)) return "";
                File f = imgFile(id);
                if (!f.exists()) return "";
                FileInputStream in = new FileInputStream(f);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                return "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void delImage(String id) {
            if (okId(id)) imgFile(id).delete();
        }

        @JavascriptInterface
        public boolean saveFile(String name, String mime, String text) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) return false;
                OutputStream o = getContentResolver().openOutputStream(u);
                o.write(text.getBytes(StandardCharsets.UTF_8));
                o.close();
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void pickBackup() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, REQ_PICK);
            });
        }

        @JavascriptInterface
        public void setReminder(final boolean on, final int h, final int m) {
            runOnUiThread(() -> {
                ReminderReceiver.configure(MainActivity.this, on, h, m);
                if (on && Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 21);
                }
            });
        }

        @JavascriptInterface
        public void setReminderText(String t) {
            getSharedPreferences("rem", 0).edit().putString("txt", t).apply();
        }

        @JavascriptInterface
        public void widgetData(String bal, String sub, String lang) {
            getSharedPreferences("w", 0).edit().putString("bal", bal).putString("sub", sub)
                    .putString("lang", lang).apply();
            QWidget.refresh(MainActivity.this);
        }

        @JavascriptInterface
        public void setCfg(String json) {
            getSharedPreferences("q", 0).edit().putString("cfg", json).apply();
        }

        @JavascriptInterface
        public String takePending() {
            SharedPreferences p = getSharedPreferences("q", 0);
            String s = p.getString("pending", "[]");
            p.edit().putString("pending", "[]").apply();
            return s;
        }

        @JavascriptInterface
        public void setBars(final boolean dark) {
            runOnUiThread(() -> applyBars(dark));
        }

        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                pm.print("Qarajat", web.createPrintDocumentAdapter("Qarajat"), new PrintAttributes.Builder().build());
            });
        }

        @JavascriptInterface
        public void listen(final String lang) {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                    i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Айтыңыз: түскі ас екі мың");
                    startActivityForResult(i, REQ_VOICE);
                } catch (Exception e) {
                    js("toast('Дауыс тану қолжетімсіз')");
                }
            });
        }

        @JavascriptInterface
        public boolean bioAvailable() {
            try {
                BiometricManager m = (BiometricManager) getSystemService(BIOMETRIC_SERVICE);
                return m != null && m.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void biometric() {
            runOnUiThread(() -> {
                try {
                    BiometricPrompt p = new BiometricPrompt.Builder(MainActivity.this)
                            .setTitle("Қаражат")
                            .setSubtitle("Саусақ ізімен немесе бет-әлпетпен ашыңыз")
                            .setNegativeButton("Кодты енгізу", getMainExecutor(), (d, w) -> { })
                            .build();
                    p.authenticate(new CancellationSignal(), getMainExecutor(),
                            new BiometricPrompt.AuthenticationCallback() {
                                @Override
                                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                                    js("onBio()");
                                }
                            });
                } catch (Exception e) {
                    // ignore: PIN remains available
                }
            });
        }
    }

    private String saveImage(Uri u) {
        try {
            Bitmap b = ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(), u),
                    (dec, info, src) -> {
                        int w = info.getSize().getWidth();
                        int h = info.getSize().getHeight();
                        int m = Math.max(w, h);
                        if (m > 1280) {
                            float f = 1280f / m;
                            dec.setTargetSize(Math.round(w * f), Math.round(h * f));
                        }
                        dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                    });
            String id = "r" + System.currentTimeMillis();
            File dir = new File(getFilesDir(), "receipts");
            dir.mkdirs();
            FileOutputStream o = new FileOutputStream(new File(dir, id + ".jpg"));
            b.compress(Bitmap.CompressFormat.JPEG, 80, o);
            o.close();
            return id;
        } catch (Exception e) {
            return "";
        }
    }

    private void startChooser(int req) {
        pending = null;
        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "cheque_" + System.currentTimeMillis() + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            pending = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (pending != null) {
                cam.putExtra(MediaStore.EXTRA_OUTPUT, pending);
                cam.setClipData(ClipData.newRawUri("", pending));
                cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
        } catch (Exception e) {
            pending = null;
        }
        Intent gal = new Intent(Intent.ACTION_GET_CONTENT);
        gal.setType("image/*");
        Intent ch = Intent.createChooser(gal, "Чек суретін таңдаңыз");
        if (pending != null) ch.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        startActivityForResult(ch, req);
    }

    private void recognize(Uri u, final String id) {
        try {
            InputImage img = InputImage.fromFilePath(this, u);
            TextRecognizer r = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            r.process(img)
                    .addOnSuccessListener(t -> js("onReceipt(" + JSONObject.quote(t.getText()) + ",'" + id + "')"))
                    .addOnFailureListener(e -> js("onReceipt('','" + id + "')"));
        } catch (Exception e) {
            js("onReceipt('','" + id + "')");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SCAN || req == REQ_PHOTO) {
            Uri u = null;
            if (res == RESULT_OK) {
                u = (data != null && data.getData() != null) ? data.getData() : pending;
            }
            if (pending != null && !pending.equals(u)) {
                try {
                    getContentResolver().delete(pending, null, null);
                } catch (Exception e) {
                    // ignore
                }
            }
            pending = null;
            if (u != null) {
                final Uri fu = u;
                final boolean scan = req == REQ_SCAN;
                if (scan) js("toast('Чек оқылуда...')");
                new Thread(() -> {
                    final String id = saveImage(fu);
                    if (scan) runOnUiThread(() -> recognize(fu, id));
                    else js("onPhoto('" + id + "')");
                }).start();
            }
        } else if (req == REQ_VOICE) {
            if (res == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) js("onVoice(" + JSONObject.quote(r.get(0)) + ")");
            }
        } else if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) {
            try {
                InputStream in = getContentResolver().openInputStream(data.getData());
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                String text = new String(bo.toByteArray(), StandardCharsets.UTF_8);
                js("onBackupText(" + JSONObject.quote(text) + ")");
            } catch (Exception e) {
                js("toast('Файлды оқу мүмкін болмады')");
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
