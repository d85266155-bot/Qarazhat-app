package kz.qarajat;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_SCAN = 11;
    private static final int REQ_PICK = 12;
    private WebView web;
    private Uri pending;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    public class Bridge {
        @JavascriptInterface
        public void scanReceipt() {
            runOnUiThread(() -> startScan());
        }

        @JavascriptInterface
        public boolean saveFile(String name, String mime, String text) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) return false;
                OutputStream o = getContentResolver().openOutputStream(u);
                o.write(text.getBytes(StandardCharsets.UTF_8));
                o.close();
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void pickBackup() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, REQ_PICK);
            });
        }

        @JavascriptInterface
        public void setReminder(final boolean on, final int h, final int m) {
            runOnUiThread(() -> {
                ReminderReceiver.configure(MainActivity.this, on, h, m);
                if (on && Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 21);
                }
            });
        }

        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                pm.print("Qarajat", web.createPrintDocumentAdapter("Qarajat"), new PrintAttributes.Builder().build());
            });
        }
    }

    private void startScan() {
        pending = null;
        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "cheque_" + System.currentTimeMillis() + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            pending = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (pending != null) {
                cam.putExtra(MediaStore.EXTRA_OUTPUT, pending);
                cam.setClipData(ClipData.newRawUri("", pending));
                cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
        } catch (Exception e) {
            pending = null;
        }
        Intent gal = new Intent(Intent.ACTION_GET_CONTENT);
        gal.setType("image/*");
        Intent ch = Intent.createChooser(gal, "Чек суретін таңдаңыз");
        if (pending != null) ch.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        startActivityForResult(ch, REQ_SCAN);
    }

    private void recognize(Uri u) {
        try {
            js("toast('Чек оқылуда...')");
            InputImage img = InputImage.fromFilePath(this, u);
            TextRecognizer r = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            r.process(img)
                    .addOnSuccessListener(t -> js("onReceipt(" + JSONObject.quote(t.getText()) + ")"))
                    .addOnFailureListener(e -> js("onReceipt('')"));
        } catch (Exception e) {
            js("onReceipt('')");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SCAN) {
            Uri u = null;
            if (res == RESULT_OK) {
                u = (data != null && data.getData() != null) ? data.getData() : pending;
            }
            if (pending != null && !pending.equals(u)) {
                try {
                    getContentResolver().delete(pending, null, null);
                } catch (Exception e) {
                    // ignore
                }
            }
            pending = null;
            if (u != null) recognize(u);
        } else if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) {
            try {
                InputStream in = getContentResolver().openInputStream(data.getData());
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                String text = new String(bo.toByteArray(), StandardCharsets.UTF_8);
                js("onBackupText(" + JSONObject.quote(text) + ")");
            } catch (Exception e) {
                js("toast('Файлды оқу мүмкін болмады')");
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
