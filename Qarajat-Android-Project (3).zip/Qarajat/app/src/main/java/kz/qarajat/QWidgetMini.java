package kz.qarajat;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class QWidgetMini extends AppWidgetProvider {

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) m.updateAppWidget(id, build(c));
    }

    static RemoteViews build(Context c) {
        SharedPreferences p = c.getSharedPreferences("w", 0);
        boolean ru = "ru".equals(p.getString("lang", "kk"));
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_mini);
        v.setTextViewText(R.id.wm_bal, p.getString("bal", "—"));
        v.setTextViewText(R.id.wm_sub, p.getString("sub", ru ? "Откройте приложение" : "Қосымшаны ашыңыз"));
        v.setOnClickPendingIntent(R.id.wm_inc, QWidget.quick(c, "i", 51));
        v.setOnClickPendingIntent(R.id.wm_exp, QWidget.quick(c, "e", 52));
        v.setOnClickPendingIntent(R.id.wm_root, QWidget.open(c, "", 50));
        return v;
    }
}
